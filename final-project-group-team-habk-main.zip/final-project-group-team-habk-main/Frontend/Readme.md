# UTube Frontend


## Steps to Run:
- Navigate to the React App
 -- cd frontend
 -- cd UTube
- Run the following commands in the terminal
-- npm install react-icons
-- npm install sass --save
-- npm install react-router-dom
-- npm install react-icons
- After all the dependencies are installed make sure the backend is running and run the below command
 -- npm start