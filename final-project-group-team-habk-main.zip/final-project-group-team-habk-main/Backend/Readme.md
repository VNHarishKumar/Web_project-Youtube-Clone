# UTube Backend


## Steps to run:
- Navigate the backend folder
 -- cd backend
- Run the following commands in the terminal
 -- npm start
