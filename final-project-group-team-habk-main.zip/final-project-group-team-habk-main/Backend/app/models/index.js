import User from "./../models/user.js";
import Video from "./../models/videos.js";
import Feeling from "./../models/feeling.js";

export default { User,Video,Feeling };
