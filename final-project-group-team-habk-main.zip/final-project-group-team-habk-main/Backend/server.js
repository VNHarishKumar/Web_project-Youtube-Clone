import app from "./app/app.js";

const port = 9002;

app.listen(port, () => console.log(`app is running on port ${port}`));
